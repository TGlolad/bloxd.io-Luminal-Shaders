// =====================================================================
//  Lumina Shaders - settings
//  Lumina Luminous Aqua Water: bright clear turquoise water with day/night colour adaptation.
//  Inspired by BSL Shaders by capttatsu; not affiliated, no BSL code used.
//
//  Turn a feature OFF by putting // in front of its #define line.
//  Tweak the numbers below to taste, then load the pack again.
// =====================================================================

#define SUN_LIGHTING       // warm sunlit faces, soft blue shade, golden hour, blue nights
#define FAKE_SHADOWS       // under trees / overhangs lose direct sun (only with Graphics > Enable Lighting)
#define FOLIAGE_WIND       // grass, flowers and crops sway in the wind (off automatically in competitive games)
#define NIGHT_SHIFT        // nights look less colourful and more blue, like real eyes in the dark
#define MAFIA_SAND         // sand is lit and coloured exactly like the Mafia shaders (see 40_sand.wgsl)
#define FOLIAGE_GLOW       // leaves and grass light up when the sun is behind them
#define ATMOSPHERE         // distance haze that glows towards the sun
#define HIGHLIGHT_GLOW     // bright surfaces get a soft warm glow (BSL's dreamy look)
#define TORCH_GLOW         // warm, rich light from torches, lamps and held lights
#define CAVE_DEPTH         // caves away from torches get darker
#define WAVY_WATER         // water rises and falls (switched off automatically in competitive games)
#define WATER_REFLECTIONS  // sky + cloud reflections, sun and moon glints on water
#define REFLECTED_CLOUDS   // moving clouds in the water reflections
#define LAVA_GLOW          // lava glows and slowly flickers
#define BLOCK_VARIATION    // tiny brightness change per block, breaks up repeating textures
#define COLOUR_GRADING     // saturation, cinematic tones and contrast

// ---- colour grading ----
const EXPOSURE: f32 = 0.99;
const SATURATION: f32 = 1.02;       // restrained, natural saturation
const VIBRANCE: f32 = 0.06;
const CONTRAST: f32 = 0.10;
const SPLIT_TONING: f32 = 0.28;
const SHADOW_TONE: vec3f = vec3f(0.97, 0.99, 1.025);
const HIGHLIGHT_TONE: vec3f = vec3f(1.035, 1.015, 0.975); // subtle warm highlights
const GLOBAL_TINT: vec3f = vec3f(1.015, 1.0, 0.985); // near-neutral daylight
const GLOW_THRESHOLD: f32 = 0.86;
const GLOW_STRENGTH: f32 = 0.075;
const GLOW_TINT: vec3f = vec3f(1.0, 0.965, 0.9);

// ---- sky ----
const SUN_TINT: vec3f = vec3f(1.0, 0.965, 0.91); // neutral daylight sun
const SUNSET_TINT: vec3f = vec3f(1.0, 0.67, 0.43); // restrained amber at sunset
const SKY_ZENITH: vec3f = vec3f(0.22, 0.42, 0.72);

// ---- sun ----
const LIGHTING_STRENGTH: f32 = 1.0;
const SUN_BRIGHTNESS: f32 = 1.12;
const SHADOW_COLOUR: vec3f = vec3f(0.72, 0.76, 0.84); // cool, lifted ambient shade
const SHADOW_LEVEL_LOW: f32 = 13.6;   // sky level (0-15) at or below this = full shadow
const SHADOW_LEVEL_HIGH: f32 = 14.95; // sky level above this = full sun (15 = open sky)
const BRIGHT_PROTECT: f32 = 0.7;      // stops sand/snow getting too bright: 0 = off, 1 = max
const HIGHLIGHT_KNEE: f32 = 0.8;      // brightness where colours start rolling off (lower = calmer highlights)
const NIGHT_SHIFT_AMOUNT: f32 = 0.22;
const SAND_MIN_RED: f32 = 0.3;        // MAFIA_SAND: raise if non-sand blocks get the sand look, lower if dark sand misses it

// ---- wind ----
const WIND_STRENGTH: f32 = 0.024;   // restrained movement, fewer distracting swings
const WIND_SPEED: f32 = 1.5;
const GOLDEN_HOUR: f32 = 0.92;
const NIGHT_TINT: f32 = 0.65;
const FOLIAGE_GLOW_STRENGTH: f32 = 0.24;

// ---- atmosphere ----
const HAZE_DENSITY: f32 = 0.008;
const HAZE_AMOUNT: f32 = 0.42;      // distance atmosphere without milky washout

// ---- torches and caves ----
const TORCH_STRENGTH: f32 = 0.48;
const CAVE_DARKNESS: f32 = 0.22;

// ---- water ----
const WATER_COLOUR: vec3f = vec3f(0.34, 0.78, 0.82); // bright clear aqua base
const WATER_TINT: f32 = 0.48;
const WAVE_HEIGHT: f32 = 0.045;
const WAVE_SPEED: f32 = 0.62;
const RIPPLE_STRENGTH: f32 = 0.042;
const WATER_REFLECTIVITY: f32 = 0.78;
const WATER_CLARITY: f32 = 0.82;
const SUN_GLINT: f32 = 0.82;

// ---- lava and blocks ----
const LAVA_BRIGHTNESS: f32 = 0.55;
const VARIATION_AMOUNT: f32 = 0.018;
