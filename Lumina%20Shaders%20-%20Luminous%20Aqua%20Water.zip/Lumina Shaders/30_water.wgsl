// Lumina Shaders - Luminous Aqua Water
// Lighter turquoise daylight water, calm natural wave layers, and adaptive dusk/night tones.
// Uses the existing Bloxd shader hooks; no extra render passes or textures are required.

// One travelling sine wave: x = height, yz = slope along world x and z.
fn wave(p: vec2f, t: f32, dir: vec2f, freq: f32, speed: f32, amp: f32) -> vec3f {
    let phase = dot(p, dir) * freq + t * speed;
    return vec3f(sin(phase) * amp, dir * (cos(phase) * amp * freq));
}

// Three broad waves and three low-amplitude detail ripples. This keeps motion
// organic without adding texture samples or expensive extra passes.
fn waveSum(p: vec2f, time: f32, detail: bool) -> vec3f {
    let t = time * WAVE_SPEED;
    var w = wave(p, t, vec2f(0.82, 0.57), 1.05, 0.82, 0.31)
        + wave(p, t, vec2f(-0.55, 0.84), 1.9, 1.17, 0.18)
        + wave(p, t, vec2f(0.27, -0.96), 3.05, 1.53, 0.10);
    if (detail) {
        w = w + wave(p, t, vec2f(0.96, 0.28), 6.8, 2.6, 0.028)
            + wave(p, t, vec2f(-0.71, -0.7), 9.4, 3.2, 0.018)
            + wave(p, t, vec2f(0.1, 0.99), 12.8, 3.9, 0.012);
    }
    return w;
}

fn waterNormal(n0: vec3f, worldPos: vec3f, time: f32) -> vec3f {
    if (n0.y < 0.5) { return n0; }
    let g = waveSum(worldPos.xz, time, true).yz * RIPPLE_STRENGTH;
    return normalize(vec3f(g.x, 1.0, g.y));
}

fn fresnel(n: vec3f, v: vec3f) -> f32 {
    let cosTheta = clamp(abs(dot(n, v)), 0.0, 1.0);
    // Real water has a low face-on reflection and stronger grazing-angle reflection.
    return 0.02 + 0.98 * pow(1.0 - cosTheta, 5.0);
}

fn isLava(c: vec3f) -> bool {
    return c.r > 0.45 && c.r > c.g * 1.35 && c.b < c.r * 0.5;
}

fn reflectedSky(r: vec3f, l: BloxdLightIn) -> vec3f {
    let sunDir = bloxdSunDirection();
    let day = dayAmount(sunDir);
    var col = skyColour(r, sunDir, l.fogColour);
#ifdef REFLECTED_CLOUDS
    if (r.y > 0.02) {
        let uv = r.xz / (r.y + 0.15) * 1.6 + vec2f(bloxdTime() * 0.018, bloxdTime() * 0.011);
        let cover = smoothstep(0.45, 0.75, cloudNoise(uv));
        let cloudCol = mix(vec3f(0.035, 0.065, 0.12), mix(vec3f(0.92, 0.97, 1.0), sunColour(sunDir), 0.45), day);
        col = mix(col, cloudCol, cover * smoothstep(0.02, 0.25, r.y) * 0.72);
    }
#endif
    // Slightly lift reflected sky colour in daylight; keep moonlit water deep, not black.
    col = mix(col * 0.72, col * 1.04, day);
    return col;
}

fn waterShade(cIn: vec3f, l: BloxdLightIn) -> vec3f {
    let n0 = normalize(l.normal);
    let v = normalize(bloxdEyePosition() - l.position);
    if (dot(n0, v) <= 0.0) { return cIn; }
    let n = waterNormal(n0, l.position + vec3f(bloxdOriginOffset()), bloxdTime());
    let f = fresnel(n, v);
    let r = reflect(-v, n);
    let sunDir = bloxdSunDirection();
    let day = dayAmount(sunDir);
#ifdef BLOXD_LIGHTING
    let sky = l.skyLight;
#else
    let sky = 1.0;
#endif
    let refl = reflectedSky(r, l) * mix(0.24, 1.0, sky);
    // Keep reflection most visible at shallow angles, so the water remains bright and clear head-on.
    var c = mix(cIn, refl, clamp(f * WATER_REFLECTIVITY, 0.0, 0.88));
    if (hasSun(sunDir)) {
        let rs = max(dot(r, sunDir), 0.0);
        // Broad, restrained glimmer plus a small crisp sparkle.
        let glint = pow(rs, 150.0) * 1.65 + pow(rs, 28.0) * 0.09;
        c = c + sunColour(sunDir) * (glint * SUN_GLINT * day * sky);
        // Subtle cool moon-facing glints after dark; not a fake bright sun at night.
        let rm = max(dot(r, -sunDir), 0.0);
        c = c + vec3f(0.48, 0.66, 0.88) * (pow(rm, 190.0) * 0.38 * SUN_GLINT * (1.0 - day) * sky);
    }
    return c;
}

#ifndef BLOXD_STRICT
#ifdef WAVY_WATER
fn bloxdLiquidVertex(v: BloxdVertexIn) -> BloxdVertex {
    var o = bloxdDefaultVertex(v);
    let worldPos = v.position + vec3f(bloxdOriginOffset());
    let h = waveSum(worldPos.xz, bloxdTime(), false).x;
    // Small coherent vertical movement avoids exaggerated choppy/blocky motion.
    o.position.y = o.position.y - WAVE_HEIGHT * (0.5 + 0.5 * h);
    return o;
}
#endif
#endif

fn bloxdLiquidSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var o = bloxdDefaultSurface(s);
    if (isLava(s.colour)) {
#ifdef LAVA_GLOW
        let worldPos = s.position + vec3f(bloxdOriginOffset());
        let flicker = 0.85 + 0.15 * sin(bloxdTime() * 2.3 + worldPos.x * 0.7 + worldPos.z * 0.9);
        o.emission = s.colour * (LAVA_BRIGHTNESS * flicker);
#endif
        return o;
    }
    let sunDir = bloxdSunDirection();
    let day = dayAmount(sunDir);
    // Bright shallow aqua by day; cooler blue at twilight; quiet deep-blue tint at night.
    let dayWater = vec3f(0.34, 0.78, 0.82);
    let twilightWater = vec3f(0.20, 0.48, 0.66);
    let nightWater = vec3f(0.075, 0.19, 0.34);
    let lightPhase = smoothstep(0.08, 0.62, day);
    let duskBlend = smoothstep(0.0, 0.25, day) * (1.0 - smoothstep(0.25, 0.62, day));
    let adaptiveWater = mix(nightWater, twilightWater, smoothstep(0.0, 0.28, day));
    let finalWater = mix(adaptiveWater, dayWater, lightPhase);
    let baseTint = mix(finalWater, WATER_COLOUR, 0.18);
    o.colour = mix(o.colour, baseTint * max(luminance(o.colour) * 1.45, 0.42), WATER_TINT);
#ifdef BLOXD_ALPHA
    let n = waterNormal(s.normal, s.position + vec3f(bloxdOriginOffset()), bloxdTime());
    let f = fresnel(n, normalize(bloxdEyePosition() - s.position));
    // Slightly clearer surface at face-on angles, naturally more reflective at grazing angles.
    var a = mix(s.alpha * WATER_CLARITY, 1.0, f * 0.72);
#ifdef BLOXD_STRICT
    a = max(a, s.alpha);
#endif
    o.alpha = clamp(a, 0.0, 1.0);
#endif
    return o;
}

fn bloxdLiquidLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var o = bloxdDefaultLight(s, l);
    if (l.fogVisibility < 0.02) { return o; }
    var c = l.litColour;
    if (!isLava(s.colour)) {
        c = worldLight(c, s.colour, l);
#ifdef WATER_REFLECTIONS
        c = waterShade(c, l);
#endif
    }
    o.colour = finishColour(c, s, l);
    return o;
}
