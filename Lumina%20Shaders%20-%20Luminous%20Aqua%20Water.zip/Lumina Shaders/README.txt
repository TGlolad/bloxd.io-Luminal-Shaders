Lumina Shaders — Luminous Aqua Water Edition

Main changes
- Water colour has been redesigned: bright aqua/turquoise during daylight, cooler blue around twilight, and deep blue at night.
- Water tint is stronger so the new palette is visible in-game.
- Reflection behaviour uses the existing sky/cloud reflection hooks and increases the grazing-angle Fresnel effect.
- Daytime sun glints are softer and broader; nighttime glints are subdued and cool.
- Wave layers have been rewritten with slower broad swells and low-amplitude ripples to avoid an overly noisy surface.
- No additional texture reads or render passes were introduced.

Compatibility/testing
- Original pack structure and Bloxd shader hook names are preserved.
- ZIP integrity and basic WGSL delimiter checks were run.
- This has not been compiled or benchmarked inside Bloxd; in-game appearance and FPS still need testing.
