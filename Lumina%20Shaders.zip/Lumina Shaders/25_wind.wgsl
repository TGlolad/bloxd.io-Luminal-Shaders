// Lumina Shaders - grass, flowers and crops sway in the wind.
//
// The vertex hook gets no block id, so plants are found by position alone:
// a cube's corners always sit on a block edge (fract = 0), while plant models
// have their corners inside the block. Idea from the Aurora Celestial / Mafia pack.
//
// The movement depends only on world position and time, so vertices that share a
// spot always move together and nothing tears. Competitive (strict) games never
// run vertex hooks, so there the plants simply stand still.

#ifndef BLOXD_STRICT
#ifdef FOLIAGE_WIND
fn bloxdTerrainVertex(v: BloxdVertexIn) -> BloxdVertex {
    var o = bloxdDefaultVertex(v);
    let world = v.position + vec3f(bloxdOriginOffset());
    let fx = fract(world.x);
    let fz = fract(world.z);
    let inside = smoothstep(0.03, 0.12, fx) * smoothstep(0.03, 0.12, 1.0 - fx)
        * smoothstep(0.03, 0.12, fz) * smoothstep(0.03, 0.12, 1.0 - fz);
    if (inside > 0.001) {
        let phase = dot(world.xz, vec2f(0.11, 0.13)) + bloxdTime() * WIND_SPEED;
        let gust = 0.75 + 0.25 * sin(bloxdTime() * 0.21 + dot(world.xz, vec2f(0.007, 0.009)));
        let sway = (0.62 * sin(phase) + 0.38 * sin(phase * 1.73 + 1.3)) * gust * WIND_STRENGTH * inside;
        o.position.x = o.position.x + 0.82 * sway;
        o.position.z = o.position.z + 0.57 * sway;
    }
    return o;
}
#endif
#endif
