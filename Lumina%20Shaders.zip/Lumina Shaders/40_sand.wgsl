// Lumina Shaders - sand.
//
// Sand (and sand-coloured blocks like sandstone) is lit and graded exactly the
// way the Mafia shaders (Aurora Celestial v4) do it: its light budget, sun / sky /
// moon colouring, micro relief, filmic tone curve and colour grade, with its own
// numbers. Everything else in the world keeps the Lumina look.
// Not carried over: its cloud shadows and its distance haze (that haze only shows
// with Graphics > Show Fog on).

// ---- Mafia numbers (copied as-is) ----
const SD_EXPOSURE: f32 = 0.96;
const SD_TONEMAP_MIX: f32 = 0.45;
const SD_BRIGHTNESS: f32 = 1.00;
const SD_CONTRAST: f32 = 0.45;
const SD_SATURATION: f32 = 1.10;
const SD_VIBRANCE: f32 = 0.38;
const SD_HIGHLIGHT_DESAT: f32 = 0.25;
const SD_SHADOW_TINT: vec3f = vec3f(0.93, 0.975, 1.08);
const SD_SHADOW_TINT_RANGE: f32 = 0.38;
const SD_SUN_STRENGTH: f32 = 0.85;
const SD_SHADOW_SUN_FLOOR: f32 = 0.16;
const SD_AMBIENT_SHADE_FLOOR: f32 = 0.34;
const SD_FACE_CONTRAST: f32 = 0.30;
const SD_NIGHT_DIM: f32 = 0.92;
const SD_LOCAL_KEEP: f32 = 0.85;
const SD_SHADOW_SPREAD: f32 = 0.30;
const SD_SHADOW_TINT_COOL: f32 = 0.50;
const SD_SUN_COLOUR_LOW: vec3f = vec3f(1.42, 0.60, 0.28);
const SD_SUN_COLOUR_MID: vec3f = vec3f(1.20, 0.94, 0.72);
const SD_SUN_COLOUR_HIGH: vec3f = vec3f(1.02, 1.00, 0.96);
const SD_SUN_GAIN: f32 = 0.20;
const SD_SUN_TINT_MIX: f32 = 0.60;
const SD_SUN_DIRECTION_BLEND: f32 = 0.60;
const SD_SUN_SPECULAR: f32 = 0.018;
const SD_SKY_OPEN_LEVEL: f32 = 14.92;
const SD_SKY_OPEN_SPAN_HARD: f32 = 1.15;
const SD_SKY_OPEN_SPAN_SOFT: f32 = 0.50;
const SD_AO_LEVEL_LOW: f32 = 3.00;
const SD_AO_LEVEL_HIGH: f32 = 14.60;
const SD_SKY_EDGE_SOFT: f32 = 2.60;
const SD_SKY_EDGE_MIN: f32 = 0.10;
const SD_SKY_TINT: vec3f = vec3f(0.90, 0.965, 1.07);
const SD_BOUNCE_TINT: vec3f = vec3f(1.05, 0.99, 0.925);
const SD_AMBIENT_AMOUNT: f32 = 0.45;
const SD_HEMI_GAIN: f32 = 0.02;
const SD_SHELTER_SINK: f32 = 0.26;
const SD_TORCH_GAIN: f32 = 0.34;
const SD_TORCH_TINT: f32 = 0.45;
const SD_TORCH_DAY_SUPPRESS: f32 = 0.70;
const SD_MOON_COLOUR: vec3f = vec3f(0.46, 0.62, 1.00);
const SD_MOON_GAIN: f32 = 0.11;
const SD_MOON_SKY_GAIN: f32 = 0.08;
const SD_SURFACE_RELIEF_STRENGTH: f32 = 0.55;
const SD_SURFACE_RELIEF_SIGN: f32 = 1.0;
const SD_SUN_RELIEF_SHADE: f32 = 0.45;

// ---- which pixels count as sand ----
// Pale, warm and only lightly saturated: green 85-100% of red, blue 55-85% of red.
// Ratios stay the same on light and dark grains, so the mask doesn't speckle.
fn sandMask(c: vec3f) -> f32 {
    let r = max(c.r, 0.001);
    let gr = c.g / r;
    let br = c.b / r;
    return smoothstep(SAND_MIN_RED, SAND_MIN_RED + 0.12, c.r)
        * smoothstep(0.82, 0.86, gr) * (1.0 - smoothstep(0.99, 1.03, gr))
        * smoothstep(0.52, 0.57, br) * (1.0 - smoothstep(0.84, 0.9, br));
}

// ---- small helpers ----
fn sdSat(x: f32) -> f32 {
    return clamp(x, 0.0, 1.0);
}

fn sdLuma(c: vec3f) -> f32 {
    return dot(c, vec3f(0.2126, 0.7152, 0.0722));
}

fn sdMax(v: vec3f) -> f32 {
    return max(v.r, max(v.g, v.b));
}

fn sdMin(v: vec3f) -> f32 {
    return min(v.r, min(v.g, v.b));
}

fn sdUnitOr(v: vec3f, fallback: vec3f) -> vec3f {
    let len2 = dot(v, v);
    return select(fallback, v * inverseSqrt(max(len2, 1e-8)), len2 > 1e-8);
}

// Same brightness, only the hue: so a light colour can tint without darkening.
fn sdTintOf(c: vec3f) -> vec3f {
    let safe = max(c, vec3f(1e-4));
    return safe / max(sdLuma(safe), 1e-4);
}

// ---- the voxel light field ----
fn sdSkyLevel(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    return rawSkyLevel(l.skyLight);
#else
    return 15.0;
#endif
}

fn sdEdgeSoft(level: f32, scale: f32) -> f32 {
    return max(fwidth(level) * SD_SKY_EDGE_SOFT * scale, SD_SKY_EDGE_MIN);
}

fn sdSkyOpen(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    let level = sdSkyLevel(l);
    let soft = sdEdgeSoft(level, 0.22);
    let span = mix(SD_SKY_OPEN_SPAN_HARD, SD_SKY_OPEN_SPAN_SOFT, sdSat(SD_SHADOW_SPREAD));
    return smoothstep(SD_SKY_OPEN_LEVEL - span - soft, SD_SKY_OPEN_LEVEL + 0.06 + soft, level);
#else
    return 1.0;
#endif
}

fn sdSkyAO(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    let level = sdSkyLevel(l);
    let soft = sdEdgeSoft(level, 0.35);
    let openness = smoothstep(SD_AO_LEVEL_LOW - soft, SD_AO_LEVEL_HIGH + soft, level);
    return mix(SD_AMBIENT_SHADE_FLOOR, 1.0, openness);
#else
    return 1.0;
#endif
}

fn sdLocalLight(l: BloxdLightIn) -> f32 {
#ifdef BLOXD_LIGHTING
    return sdMax(max(l.blockLight + l.heldLight, vec3f(0.0)));
#else
    return 0.0;
#endif
}

fn sdLocalLightColour(l: BloxdLightIn) -> vec3f {
#ifdef BLOXD_LIGHTING
    return max(l.blockLight + l.heldLight, vec3f(0.0));
#else
    return vec3f(1.0, 1.0, 1.0);
#endif
}

fn sdSkyAmbientColour(l: BloxdLightIn) -> vec3f {
#ifdef BLOXD_LIGHTING
    return max(l.skyLightColour, vec3f(0.0));
#else
    return vec3f(1.0, 1.0, 1.0);
#endif
}

fn sdGroundAmbientColour(l: BloxdLightIn) -> vec3f {
#ifdef BLOXD_LIGHTING
    return max(l.ambientLightColour, vec3f(0.0));
#else
    return vec3f(1.0, 1.0, 1.0);
#endif
}

// ---- sun, moon and time of day ----
fn sdSunVector(l: BloxdLightIn) -> vec3f {
    return sdUnitOr(bloxdSunDirection(), vec3f(0.0, 1.0, 0.0));
}

fn sdSunPresence(l: BloxdLightIn) -> f32 {
    return smoothstep(0.02, 0.35, length(bloxdSunDirection()));
}

fn sdDay(l: BloxdLightIn) -> f32 {
    return mix(1.0, smoothstep(-0.13, 0.24, sdSunVector(l).y), sdSunPresence(l));
}

fn sdSunColour(l: BloxdLightIn) -> vec3f {
    let h = sdSunVector(l).y;
    let low = mix(SD_SUN_COLOUR_LOW, SD_SUN_COLOUR_MID, smoothstep(0.0, 0.20, h));
    return mix(low, SD_SUN_COLOUR_HIGH, smoothstep(0.17, 0.62, h));
}

fn sdView(l: BloxdLightIn) -> vec3f {
    return sdUnitOr(bloxdEyePosition() - l.position, vec3f(0.0, 0.0, 1.0));
}

// ---- specular ----
fn sdFresnel(cosTheta: f32, f0: f32) -> f32 {
    let m = sdSat(1.0 - cosTheta);
    return f0 + (1.0 - f0) * m * m * m * m * m;
}

fn sdGgx(n: vec3f, v: vec3f, toSun: vec3f, roughness: f32) -> f32 {
    let h = sdUnitOr(v + toSun, n);
    let noH = sdSat(dot(n, h));
    let noV = max(sdSat(dot(n, v)), 0.04);
    let noL = sdSat(dot(n, toSun));
    let voH = sdSat(dot(v, h));
    let alpha = roughness * roughness;
    let a2 = alpha * alpha;
    let denom = noH * noH * (a2 - 1.0) + 1.0;
    let distribution = a2 / max(3.14159265 * denom * denom, 1e-5);
    let k = (roughness + 1.0) * (roughness + 1.0) * 0.125;
    let geometry = (noV / (noV * (1.0 - k) + k)) * (noL / (noL * (1.0 - k) + k));
    return min(distribution * geometry * sdFresnel(voH, 0.028) / (4.0 * noV + 1e-4), 2.0);
}

// ---- the light budget (how much light this pixel keeps) ----
fn sdLightBudget(l: BloxdLightIn, n: vec3f, ndl: f32, day: f32, sun: vec3f) -> f32 {
    let open = sdSkyOpen(l);
    let ao = sdSkyAO(l);
    let hemi = sdSat(n.y * 0.5 + 0.5);
    let sunWeight = SD_SUN_STRENGTH * day * mix(0.35, 1.0, sdSat(ndl));
    let overhead = smoothstep(0.04, 0.32, max(sun.y, 0.0));
    let sunLeftShadow = mix(1.0, SD_SHADOW_SUN_FLOOR, overhead);
    let sunLeft = mix(sunLeftShadow, 1.0, open);
    let ambLeft = mix(SD_AMBIENT_SHADE_FLOOR, 1.0, ao);
    let face = 1.0 + SD_FACE_CONTRAST * (hemi - 0.5);
    var amount = ambLeft * face * (1.0 - sunWeight * (1.0 - sunLeft));
    amount = amount * (1.0 + SD_SUN_GAIN * sunWeight * sunLeft);
    amount = amount * mix(SD_NIGHT_DIM, 1.0, day);
    return max(amount, sdLocalLight(l) * SD_LOCAL_KEEP);
}

// ---- micro relief: tiny bumps read from neighbouring pixels' brightness ----
fn sdReliefNormal(l: BloxdLightIn, n: vec3f) -> vec3f {
    let px = dpdx(l.position);
    let py = dpdy(l.position);
    let height = log(0.10 + max(sdLuma(max(l.engineColour, vec3f(0.0))), 0.0));
    let hx = dpdx(height);
    let hy = dpdy(height);
    let tx = cross(py, n);
    let ty = cross(n, px);
    let det = dot(px, tx);
    let gradient = (hx * tx + hy * ty) * sign(det) / max(abs(det), 1e-6);
    let bounded = gradient / (1.0 + length(gradient) * 0.10);
    let nearness = 1.0 - smoothstep(4.0, 26.0, length(l.position - bloxdEyePosition()));
    let flatness = 1.0 - smoothstep(0.04, 0.30, length(dpdx(n)) + length(dpdy(n)));
    let strength = SD_SURFACE_RELIEF_SIGN * 0.016 * SD_SURFACE_RELIEF_STRENGTH * nearness * flatness;
    return sdUnitOr(n - bounded * strength, n);
}

// ---- tone curve and grade ----
fn sdContrastCurve(c: vec3f) -> vec3f {
    let x = clamp(c, vec3f(0.0), vec3f(1.0));
    return x * x * (vec3f(3.0) - 2.0 * x);
}

fn sdFilmic(x: vec3f) -> vec3f {
    return clamp((x * (2.51 * x + 0.03)) / max(x * (2.43 * x + 0.59) + 0.14, vec3f(1e-5)), vec3f(0.0), vec3f(1.0));
}

fn sdShoulder(x: f32, knee: f32) -> f32 {
    if (x <= knee) {
        return x;
    }
    let headroom = max(1.0 - knee, 1e-3);
    return knee + headroom * (1.0 - 1.0 / (1.0 + (x - knee) / headroom));
}

fn sdGrade(colourIn: vec3f, day: f32) -> vec3f {
    var c = max(colourIn, vec3f(0.0)) * SD_EXPOSURE;
    c = mix(c, sdFilmic(c), sdSat(SD_TONEMAP_MIX));
    c = max(c * SD_BRIGHTNESS, vec3f(0.0));
    c = mix(c, sdContrastCurve(c), sdSat(SD_CONTRAST));
    let lum = sdLuma(c);
    let chroma = sdSat((sdMax(c) - sdMin(c)) / max(sdMax(c), 1e-4));
    let satAmount = SD_SATURATION * (1.0 + SD_VIBRANCE * (1.0 - chroma));
    c = max(mix(vec3f(lum), c, satAmount), vec3f(0.0));
    let shadowWeight = 1.0 - smoothstep(0.0, SD_SHADOW_TINT_RANGE, sdLuma(c));
    c = mix(c, c * SD_SHADOW_TINT, shadowWeight * 0.85);
    let highlightWeight = smoothstep(0.62, 1.0, sdLuma(c));
    c = mix(c, vec3f(sdLuma(c)), highlightWeight * SD_HIGHLIGHT_DESAT);
    let night = sdSat(1.0 - day);
    c = mix(c, vec3f(sdLuma(c)) * vec3f(0.60, 0.80, 1.14), night * 0.45);
    let peak = sdMax(c);
    c = max(c * (sdShoulder(peak, 0.90) / max(peak, 1e-5)), vec3f(0.0));
    return clamp(c, vec3f(0.0), vec3f(1.0));
}

// ---- the whole Mafia terrain pipeline for one pixel ----
// Called before any early return, so the screen-space derivatives stay valid.
fn sandLight(s: BloxdSurface, l: BloxdLightIn) -> vec3f {
    let fog = sdSat(l.fogVisibility);
    var colour = max(l.litColour, vec3f(0.0));

    let n = sdUnitOr(l.normal, vec3f(0.0, 1.0, 0.0));
    let view = sdView(l);
    let day = sdDay(l);
    let presence = sdSunPresence(l);
    let sun = sdSunVector(l);
    let open = sdSkyOpen(l);
    let lightHere = sdLocalLight(l);
    let night = 1.0 - day;
    let sunCol = sdSunColour(l);

    // direct sun: per-pixel N.sun blended with the engine's own Lambert
    let ndl = sdSat(dot(n, sun)) * presence;
    let engineNdl = max(l.directional, 0.0);
    var direct = ndl;
    if (engineNdl > 0.001) {
        direct = sdSat(mix(engineNdl, ndl, SD_SUN_DIRECTION_BLEND));
    }

    let amount = sdLightBudget(l, n, direct, day, sun);
    let sunPart = SD_SUN_STRENGTH * direct * mix(SD_SHADOW_SUN_FLOOR, 1.0, open) * day;
    let sunShare = sdSat(sunPart / max(amount, 1e-3));
    colour = colour * amount;

    // sunlight tint and a faint sheen on upward faces
    colour = colour * mix(vec3f(1.0), sdTintOf(sunCol), SD_SUN_TINT_MIX * sunShare);
    let sheen = sdGgx(n, view, sun, 0.85) * sdSat(n.y) * sunPart;
    colour = colour + sunCol * (SD_SUN_SPECULAR * sheen);

    // shade picks up the sky's colour
    let shadeWeight = sdSat(1.0 - open) * day * (1.0 - sunShare);
    colour = colour * mix(vec3f(1.0), sdTintOf(sdSkyAmbientColour(l)) * vec3f(1.0, 1.01, 1.05), shadeWeight * SD_SHADOW_TINT_COOL);

    // sky from above, warm bounce from below
    let hemi = sdSat(n.y * 0.5 + 0.5);
    let skyHue = sdTintOf(sdSkyAmbientColour(l)) * SD_SKY_TINT;
    let bounceHue = sdTintOf(sdGroundAmbientColour(l)) * SD_BOUNCE_TINT;
    let ambHue = mix(bounceHue, skyHue, hemi);
    let shelter = SD_SHELTER_SINK * (1.0 - open) * day;
    colour = colour * mix(vec3f(1.0), ambHue, sdSat(SD_AMBIENT_AMOUNT * (1.0 - shelter)));
    colour = colour * (1.0 + SD_HEMI_GAIN * (hemi - 0.5) * day * open);

    // moonlight
    colour = colour * (1.0 + SD_MOON_SKY_GAIN * night * open * max(n.y, 0.0) * presence);
    colour = colour * mix(vec3f(1.0), sdTintOf(SD_MOON_COLOUR), night * open * 0.20);
    let moonNdl = sdSat(dot(n, -sun)) * presence;
    colour = colour + SD_MOON_COLOUR * (SD_MOON_GAIN * moonNdl * night * open);

    // torches keep their own colour
    if (lightHere > 0.001) {
        let skyLit = max(sdLuma(sdSkyAmbientColour(l)), 0.0) * (0.35 + 0.65 * day) + direct * 0.6;
        let blockShare = sdSat(lightHere / max(lightHere + skyLit, 1e-4));
        let gain = SD_TORCH_GAIN * lightHere * mix(1.0, 1.0 - SD_TORCH_DAY_SUPPRESS, sdSat(open * day));
        colour = colour * (1.0 + gain);
        colour = colour * mix(vec3f(1.0), sdTintOf(sdLocalLightColour(l)), SD_TORCH_TINT * blockShare);
    }

    // micro relief: the sand grains catch the sun
    let detailN = sdReliefNormal(l, n);
    let relief = clamp(dot(detailN, sun) - dot(n, sun), -0.12, 0.12);
    colour = colour * (1.0 + relief * SD_SUN_RELIEF_SHADE * sunPart);

    // grade, then put the engine's fog back
    let graded = sdGrade(colour + s.emission, day);
    let fogged = mix(l.fogColour, graded, fog);
    return mix(l.engineColour, fogged, smoothstep(0.03, 0.11, fog));
}
