// Lumina Shaders - water and lava.

// One travelling sine wave: x = height, yz = slope along world x and z.
fn wave(p: vec2f, t: f32, dir: vec2f, freq: f32, speed: f32, amp: f32) -> vec3f {
    let phase = dot(p, dir) * freq + t * speed;
    return vec3f(sin(phase) * amp, dir * (cos(phase) * amp * freq));
}

// Big swells (height stays within -1..1), plus fine ripples that only bend the light.
fn waveSum(p: vec2f, time: f32, detail: bool) -> vec3f {
    let t = time * WAVE_SPEED;
    var w = wave(p, t, vec2f(0.8, 0.6), 1.7, 1.6, 0.5)
        + wave(p, t, vec2f(-0.53, 0.85), 2.6, 2.1, 0.3)
        + wave(p, t, vec2f(0.24, -0.97), 4.1, 2.9, 0.2);
    if (detail) {
        w = w + wave(p, t, vec2f(0.96, 0.28), 9.3, 4.7, 0.06)
            + wave(p, t, vec2f(-0.71, -0.7), 13.7, 6.1, 0.04)
            + wave(p, t, vec2f(0.1, 0.99), 19.1, 7.3, 0.025);
    }
    return w;
}

fn waterNormal(n0: vec3f, worldPos: vec3f, time: f32) -> vec3f {
    if (n0.y < 0.5) {
        return n0;
    }
    let g = waveSum(worldPos.xz, time, true).yz * RIPPLE_STRENGTH;
    return normalize(vec3f(g.x, 1.0, g.y));
}

fn fresnel(n: vec3f, v: vec3f) -> f32 {
    let cosTheta = clamp(abs(dot(n, v)), 0.0, 1.0);
    return 0.02 + 0.98 * pow(1.0 - cosTheta, 5.0);
}

fn isLava(c: vec3f) -> bool {
    return c.r > 0.45 && c.r > c.g * 1.35 && c.b < c.r * 0.5;
}

fn reflectedSky(r: vec3f, l: BloxdLightIn) -> vec3f {
    let sunDir = bloxdSunDirection();
    let day = dayAmount(sunDir);
    var col = skyColour(r, sunDir, l.fogColour);
#ifdef REFLECTED_CLOUDS
    if (r.y > 0.02) {
        let uv = r.xz / (r.y + 0.15) * 1.6 + vec2f(bloxdTime() * 0.02, bloxdTime() * 0.012);
        let cover = smoothstep(0.45, 0.75, cloudNoise(uv));
        let cloudCol = mix(vec3f(0.1, 0.11, 0.16), mix(vec3f(1.0), sunColour(sunDir), 0.6), day);
        col = mix(col, cloudCol, cover * smoothstep(0.02, 0.25, r.y) * 0.85);
    }
#endif
    return col;
}

fn waterShade(cIn: vec3f, l: BloxdLightIn) -> vec3f {
    let n0 = normalize(l.normal);
    let v = normalize(bloxdEyePosition() - l.position);
    if (dot(n0, v) <= 0.0) {
        return cIn;
    }
    let n = waterNormal(n0, l.position + vec3f(bloxdOriginOffset()), bloxdTime());
    let f = fresnel(n, v);
    let r = reflect(-v, n);
    let sunDir = bloxdSunDirection();
    let day = dayAmount(sunDir);
#ifdef BLOXD_LIGHTING
    let sky = l.skyLight;
#else
    let sky = 1.0;
#endif
    let refl = reflectedSky(r, l) * mix(0.2, 1.0, sky);
    var c = mix(cIn, refl, clamp(f * WATER_REFLECTIVITY, 0.0, 1.0));
    if (hasSun(sunDir)) {
        let rs = max(dot(r, sunDir), 0.0);
        let glint = pow(rs, 400.0) * 8.0 + pow(rs, 48.0) * 0.35;
        c = c + sunColour(sunDir) * (glint * SUN_GLINT * day * sky);
        let rm = max(dot(r, -sunDir), 0.0);
        c = c + vec3f(0.65, 0.78, 1.0) * (pow(rm, 600.0) * 2.5 * SUN_GLINT * (1.0 - day) * sky);
    }
    return c;
}

#ifndef BLOXD_STRICT
#ifdef WAVY_WATER
fn bloxdLiquidVertex(v: BloxdVertexIn) -> BloxdVertex {
    var o = bloxdDefaultVertex(v);
    let worldPos = v.position + vec3f(bloxdOriginOffset());
    let h = waveSum(worldPos.xz, bloxdTime(), false).x;
    // Only ever moves down, and every vertex at the same spot moves the same, so no gaps open up.
    o.position.y = o.position.y - WAVE_HEIGHT * (0.5 + 0.5 * h);
    return o;
}
#endif
#endif

fn bloxdLiquidSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var o = bloxdDefaultSurface(s);
    if (isLava(s.colour)) {
#ifdef LAVA_GLOW
        let worldPos = s.position + vec3f(bloxdOriginOffset());
        let flicker = 0.85 + 0.15 * sin(bloxdTime() * 2.3 + worldPos.x * 0.7 + worldPos.z * 0.9);
        o.emission = s.colour * (LAVA_BRIGHTNESS * flicker);
#endif
        return o;
    }
    o.colour = mix(o.colour, WATER_COLOUR * max(luminance(o.colour) * 1.6, 0.25), WATER_TINT);
#ifdef BLOXD_ALPHA
    let n = waterNormal(s.normal, s.position + vec3f(bloxdOriginOffset()), bloxdTime());
    let f = fresnel(n, normalize(bloxdEyePosition() - s.position));
    var a = mix(s.alpha * WATER_CLARITY, 1.0, f * 0.8);
#ifdef BLOXD_STRICT
    // competitive games: never let water become easier to see through than vanilla
    a = max(a, s.alpha);
#endif
    o.alpha = clamp(a, 0.0, 1.0);
#endif
    return o;
}

fn bloxdLiquidLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var o = bloxdDefaultLight(s, l);
    if (l.fogVisibility < 0.02) {
        return o;
    }
    var c = l.litColour;
    if (!isLava(s.colour)) {
        c = worldLight(c, s.colour, l);
#ifdef WATER_REFLECTIONS
        c = waterShade(c, l);
#endif
    }
    o.colour = finishColour(c, s, l);
    return o;
}
