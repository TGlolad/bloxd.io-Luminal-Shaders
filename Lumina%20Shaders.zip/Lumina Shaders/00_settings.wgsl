// =====================================================================
//  Lumina Shaders - settings
//  A Bloxd pack in the style of BSL: warm golden sun, soft glow,
//  hazy distance, deep orange sunsets, clear blue water.
//  Inspired by BSL Shaders by capttatsu; not affiliated, no BSL code used.
//
//  Turn a feature OFF by putting // in front of its #define line.
//  Tweak the numbers below to taste, then load the pack again.
// =====================================================================

#define SUN_LIGHTING       // warm sunlit faces, soft blue shade, golden hour, blue nights
#define FAKE_SHADOWS       // under trees / overhangs lose direct sun (only with Graphics > Enable Lighting)
#define FOLIAGE_WIND       // grass, flowers and crops sway in the wind (off automatically in competitive games)
#define NIGHT_SHIFT        // nights look less colourful and more blue, like real eyes in the dark
#define MAFIA_SAND         // sand is lit and coloured exactly like the Mafia shaders (see 40_sand.wgsl)
#define FOLIAGE_GLOW       // leaves and grass light up when the sun is behind them
#define ATMOSPHERE         // distance haze that glows towards the sun
#define HIGHLIGHT_GLOW     // bright surfaces get a soft warm glow (BSL's dreamy look)
#define TORCH_GLOW         // warm, rich light from torches, lamps and held lights
#define CAVE_DEPTH         // caves away from torches get darker
#define WAVY_WATER         // water rises and falls (switched off automatically in competitive games)
#define WATER_REFLECTIONS  // sky + cloud reflections, sun and moon glints on water
#define REFLECTED_CLOUDS   // moving clouds in the water reflections
#define LAVA_GLOW          // lava glows and slowly flickers
#define BLOCK_VARIATION    // tiny brightness change per block, breaks up repeating textures
#define COLOUR_GRADING     // saturation, cinematic tones and contrast

// ---- colour grading ----
const EXPOSURE: f32 = 1.05;
const SATURATION: f32 = 1.08;       // BSL keeps colours natural, not neon
const VIBRANCE: f32 = 0.12;
const CONTRAST: f32 = 0.16;
const SPLIT_TONING: f32 = 0.75;
const SHADOW_TONE: vec3f = vec3f(0.94, 0.97, 1.07);
const HIGHLIGHT_TONE: vec3f = vec3f(1.1, 1.02, 0.86);  // golden highlights
const GLOBAL_TINT: vec3f = vec3f(1.04, 1.0, 0.93);     // whole image slightly warm
const GLOW_THRESHOLD: f32 = 0.62;
const GLOW_STRENGTH: f32 = 0.2;
const GLOW_TINT: vec3f = vec3f(1.0, 0.9, 0.72);

// ---- sky ----
const SUN_TINT: vec3f = vec3f(1.0, 0.88, 0.68);    // golden midday sun
const SUNSET_TINT: vec3f = vec3f(1.0, 0.5, 0.22);  // deep orange sunsets
const SKY_ZENITH: vec3f = vec3f(0.24, 0.47, 0.88);

// ---- sun ----
const LIGHTING_STRENGTH: f32 = 1.0;
const SUN_BRIGHTNESS: f32 = 1.3;
const SHADOW_COLOUR: vec3f = vec3f(0.48, 0.54, 0.72); // shade colour: lower = darker shadows
const SHADOW_LEVEL_LOW: f32 = 13.6;   // sky level (0-15) at or below this = full shadow
const SHADOW_LEVEL_HIGH: f32 = 14.95; // sky level above this = full sun (15 = open sky)
const BRIGHT_PROTECT: f32 = 0.7;      // stops sand/snow getting too bright: 0 = off, 1 = max
const HIGHLIGHT_KNEE: f32 = 0.8;      // brightness where colours start rolling off (lower = calmer highlights)
const NIGHT_SHIFT_AMOUNT: f32 = 0.35;
const SAND_MIN_RED: f32 = 0.3;        // MAFIA_SAND: raise if non-sand blocks get the sand look, lower if dark sand misses it

// ---- wind ----
const WIND_STRENGTH: f32 = 0.035;   // in blocks
const WIND_SPEED: f32 = 1.5;
const GOLDEN_HOUR: f32 = 1.2;
const NIGHT_TINT: f32 = 0.65;
const FOLIAGE_GLOW_STRENGTH: f32 = 0.55;

// ---- atmosphere ----
const HAZE_DENSITY: f32 = 0.014;
const HAZE_AMOUNT: f32 = 0.65;      // BSL is hazy

// ---- torches and caves ----
const TORCH_STRENGTH: f32 = 0.65;
const CAVE_DARKNESS: f32 = 0.3;

// ---- water ----
const WATER_COLOUR: vec3f = vec3f(0.12, 0.45, 0.65);  // clear blue
const WATER_TINT: f32 = 0.5;
const WAVE_HEIGHT: f32 = 0.06;
const WAVE_SPEED: f32 = 0.9;
const RIPPLE_STRENGTH: f32 = 0.06;
const WATER_REFLECTIVITY: f32 = 0.9;
const WATER_CLARITY: f32 = 0.8;
const SUN_GLINT: f32 = 1.6;

// ---- lava and blocks ----
const LAVA_BRIGHTNESS: f32 = 0.55;
const VARIATION_AMOUNT: f32 = 0.03;
