// Lumina Shaders - shared helpers used by the terrain and water files.

const LUMA: vec3f = vec3f(0.2126, 0.7152, 0.0722);

fn luminance(c: vec3f) -> f32 {
    return dot(c, LUMA);
}

// ---------------------------------------------------------------- sun and sky

fn hasSun(sunDir: vec3f) -> bool {
    return dot(sunDir, sunDir) > 0.25;
}

// 1 in full daylight, 0 at night. Worlds without a sun count as day.
fn dayAmount(sunDir: vec3f) -> f32 {
    if (!hasSun(sunDir)) {
        return 1.0;
    }
    return smoothstep(-0.08, 0.18, sunDir.y);
}

// Peaks while the sun sits near the horizon.
fn goldenAmount(sunDir: vec3f) -> f32 {
    if (!hasSun(sunDir)) {
        return 0.0;
    }
    let e = sunDir.y;
    return smoothstep(-0.14, 0.02, e) * (1.0 - smoothstep(0.04, 0.45, e)) * GOLDEN_HOUR;
}

fn sunColour(sunDir: vec3f) -> vec3f {
    return mix(SUN_TINT, SUNSET_TINT, goldenAmount(sunDir));
}

// Sky colour looking along dir. The horizon follows the game's fog so it matches the real sky.
fn skyColour(dir: vec3f, sunDir: vec3f, horizon: vec3f) -> vec3f {
    let day = dayAmount(sunDir);
    let zenith = mix(vec3f(0.01, 0.015, 0.04), SKY_ZENITH, day);
    let h = mix(horizon, SUNSET_TINT, goldenAmount(sunDir) * 0.6);
    var col = mix(h, zenith, pow(clamp(dir.y, 0.0, 1.0), 0.6));
    if (hasSun(sunDir)) {
        let toSun = max(dot(dir, sunDir), 0.0);
        col = col + sunColour(sunDir) * ((pow(toSun, 8.0) * 0.45 + pow(toSun, 64.0) * 0.6) * day);
    }
    return col;
}

fn isFoliage(c: vec3f) -> bool {
    return c.g > 0.12 && c.g > c.r * 1.15 && c.g > c.b * 1.25;
}

// ---------------------------------------------------------------- noise

fn hash3(b: vec3i) -> f32 {
    let u = bitcast<vec3u>(b);
    var n = (u.x * 73856093u) ^ (u.y * 19349663u) ^ (u.z * 83492791u);
    n = (n ^ (n >> 16u)) * 0x45d9f3bu;
    n = n ^ (n >> 16u);
    return f32(n & 0xffffu) / 65535.0;
}

fn hash2(p: vec2f) -> f32 {
    var p3 = fract(p.xyx * 0.1031);
    p3 = p3 + dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

fn valueNoise(p: vec2f) -> f32 {
    let i = floor(p);
    let f = fract(p);
    let w = f * f * (3.0 - 2.0 * f);
    let a = hash2(i);
    let b = hash2(i + vec2f(1.0, 0.0));
    let c = hash2(i + vec2f(0.0, 1.0));
    let d = hash2(i + vec2f(1.0, 1.0));
    return mix(mix(a, b, w.x), mix(c, d, w.x), w.y);
}

fn cloudNoise(p: vec2f) -> f32 {
    var total = 0.0;
    var amp = 0.5;
    var q = p;
    for (var i = 0; i < 4; i = i + 1) {
        total = total + valueNoise(q) * amp;
        q = q * 2.03 + vec2f(17.1, 9.7);
        amp = amp * 0.5;
    }
    return total;
}

// ---------------------------------------------------------------- colour

// Leaves everything below the knee alone and rolls brighter colours down as a whole,
// so sunlit sand and snow keep their own colour instead of blowing out to white.
// (Hue-preserving shoulder, idea from the Aurora Celestial / Mafia pack.)
fn softClip(c: vec3f) -> vec3f {
    let knee = HIGHLIGHT_KNEE;
    let peak = max(c.r, max(c.g, c.b));
    if (peak <= knee) {
        return c;
    }
    let room = 1.0 - knee;
    let squeezed = knee + room * (1.0 - 1.0 / (1.0 + (peak - knee) / room));
    return c * (squeezed / peak);
}

// Bloxd hands packs sky light already pushed through its display curve
// tone(x) = 1 - (1 - x / (3 - 2x))^3 with x = level / 15. This undoes it, giving the
// real 0..15 voxel level: 15 = open sky, anything less = something is overhead.
fn rawSkyLevel(encoded: f32) -> f32 {
    let base = 1.0 - pow(max(1.0 - clamp(encoded, 0.0, 1.0), 0.0), 1.0 / 3.0);
    return 45.0 * base / max(1.0 + 2.0 * base, 0.0001);
}

fn gradeColour(cIn: vec3f) -> vec3f {
    var c = max(cIn * EXPOSURE, vec3f(0.0));
#ifdef COLOUR_GRADING
    let y = luminance(c);
    let chroma = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
    let amount = SATURATION + VIBRANCE * (1.0 - clamp(chroma * 2.0, 0.0, 1.0));
    c = max(mix(vec3f(y), c, amount), vec3f(0.0));
    let tone = mix(SHADOW_TONE, HIGHLIGHT_TONE, smoothstep(0.05, 0.75, luminance(c)));
    c = c * mix(vec3f(1.0), tone, SPLIT_TONING);
    let k = clamp(c, vec3f(0.0), vec3f(1.0));
    c = mix(c, k * k * (3.0 - 2.0 * k), CONTRAST);
    c = c * GLOBAL_TINT;
#endif
#ifdef HIGHLIGHT_GLOW
    // Not real bloom (packs can't blur the screen), but bright surfaces get a soft warm glow.
    c = c + c * GLOW_TINT * (smoothstep(GLOW_THRESHOLD, 1.2, luminance(c)) * GLOW_STRENGTH);
#endif
    return c;
}

// ---------------------------------------------------------------- lighting

fn worldLight(cIn: vec3f, albedo: vec3f, l: BloxdLightIn) -> vec3f {
    var c = cIn;
#ifdef BLOXD_LIGHTING
    let sky = l.skyLight;
#else
    let sky = 1.0;
#endif
    let sunDir = bloxdSunDirection();
    let day = dayAmount(sunDir);
#ifdef SUN_LIGHTING
    let outside = smoothstep(0.0, 0.35, sky);
    if (hasSun(sunDir)) {
#ifdef FAKE_SHADOWS
        let sunVisible = smoothstep(SHADOW_LEVEL_LOW, SHADOW_LEVEL_HIGH, rawSkyLevel(sky));
#else
        let sunVisible = 1.0;
#endif
        let ndl = dot(normalize(l.normal), sunDir);
        let direct = smoothstep(-0.05, 0.45, ndl) * sunVisible;
        // Already-bright surfaces (sand, snow, quartz) get less of the extra sun boost.
        let boost = mix(SUN_BRIGHTNESS, 1.0, smoothstep(0.55, 0.9, luminance(cIn)) * BRIGHT_PROTECT);
        let lightTint = mix(SHADOW_COLOUR, sunColour(sunDir) * boost, direct);
        c = c * mix(vec3f(1.0), lightTint, outside * day * LIGHTING_STRENGTH);
#ifdef FOLIAGE_GLOW
        if (isFoliage(albedo)) {
            let viewDir = normalize(l.position - bloxdEyePosition());
            let behind = pow(max(dot(viewDir, sunDir), 0.0), 3.0);
            c = c + albedo * vec3f(1.0, 0.85, 0.35) * (behind * outside * day * sunVisible * FOLIAGE_GLOW_STRENGTH);
        }
#endif
    }
    c = c * mix(vec3f(1.0), vec3f(0.55, 0.66, 1.0), outside * (1.0 - day) * NIGHT_TINT);
#endif
#ifdef BLOXD_LIGHTING
#ifdef TORCH_GLOW
    let torch = max(l.blockLight, l.heldLight);
    c = c + albedo * torch * vec3f(1.0, 0.68, 0.36) * (TORCH_STRENGTH * (1.0 - 0.8 * sky * day));
#endif
#ifdef CAVE_DEPTH
    let dark = (1.0 - sky) * (1.0 - clamp(luminance(l.blockLight + l.heldLight) * 2.0, 0.0, 1.0));
    c = c * (1.0 - dark * CAVE_DARKNESS);
#endif
#endif
    return c;
}

fn applyAtmosphere(c: vec3f, l: BloxdLightIn) -> vec3f {
    var col = c;
#ifdef ATMOSPHERE
    let viewVec = l.position - bloxdEyePosition();
    let dist = length(viewVec);
    let viewDir = viewVec / max(dist, 0.001);
    let hazeDir = normalize(vec3f(viewDir.x, 0.06, viewDir.z));
    let hazeCol = skyColour(hazeDir, bloxdSunDirection(), l.fogColour);
    let haze = (1.0 - exp(-dist * HAZE_DENSITY)) * HAZE_AMOUNT;
    col = mix(col, hazeCol, haze);
#endif
    return col;
}

fn finishColour(c: vec3f, s: BloxdSurface, l: BloxdLightIn) -> vec3f {
    var graded = gradeColour(applyAtmosphere(c, l));
#ifdef NIGHT_SHIFT
    // At night the eye loses colour and sees things blue-green.
    let night = 1.0 - dayAmount(bloxdSunDirection());
    graded = mix(graded, vec3f(luminance(graded)) * vec3f(0.6, 0.8, 1.14), night * NIGHT_SHIFT_AMOUNT);
#endif
    let shaded = softClip(graded + s.emission);
    return mix(l.fogColour, shaded, l.fogVisibility);
}
