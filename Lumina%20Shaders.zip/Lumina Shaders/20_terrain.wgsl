// Lumina Shaders - every solid and transparent block.

fn bloxdTerrainSurface(s: BloxdSurfaceIn) -> BloxdSurface {
    var o = bloxdDefaultSurface(s);
#ifdef BLOCK_VARIATION
    let block = vec3i(floor(s.position - s.normal * 0.5)) + bloxdOriginOffset();
    var variation = 1.0 + (hash3(block) - 0.5) * 2.0 * VARIATION_AMOUNT;
#ifdef MAFIA_SAND
    // sand follows the Mafia look exactly, and that pack has no per-block variation
    variation = mix(variation, 1.0, sandMask(s.colour));
#endif
    o.colour = o.colour * variation;
#endif
    return o;
}

fn bloxdTerrainLight(s: BloxdSurface, l: BloxdLightIn) -> BloxdLight {
    var o = bloxdDefaultLight(s, l);
#ifdef MAFIA_SAND
    // Worked out before the early return below: the sand look reads neighbouring
    // pixels, which shaders only allow while every pixel takes the same path.
    let sand = sandMask(s.colour);
    let sandColour = sandLight(s, l);
#endif
    if (l.fogVisibility < 0.02) {
        return o;
    }
    let c = worldLight(l.litColour, s.colour, l);
    o.colour = finishColour(c, s, l);
#ifdef MAFIA_SAND
    o.colour = mix(o.colour, sandColour, sand);
#endif
    return o;
}
